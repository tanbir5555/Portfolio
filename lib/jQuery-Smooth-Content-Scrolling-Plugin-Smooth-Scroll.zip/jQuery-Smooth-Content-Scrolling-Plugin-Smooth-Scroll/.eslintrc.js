module.exports = {
  extends: 'kswedberg/es5'
};
